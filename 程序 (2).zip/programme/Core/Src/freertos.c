/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "lcd.h"
#include "main.h"
#include "cmsis_os.h"
#include "adc.h"
#include "spi.h"
#include "tim.h"
#include "gpio.h"
#include "dht11.h"
#include "string.h"
#include "stdio.h"
#include "usart.h"
#include "esp.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
osThreadId_t xPUMPTaskHandle;
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
static void PUMP(void);
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */
__IO uint16_t uhADCxConvertedValue[4];
__IO uint32_t uhADCxInputVoltage[4];
uint32_t adc3_inp0,adc3_inp1,adc3_inp10,adc3_inp11;

uint8_t pump_state[15];
uint8_t pest_state[15];
uint8_t pump_state1;  //0 off 1on    
uint8_t pest_state1;     //0 normal  1butterfly 2maomao
uint16_t light_val;
uint16_t soil_val;

#define RXBUFFERSIZE  256      //�������ֽ���
char RxBuffer[RXBUFFERSIZE];   //��������
uint8_t aRxBuffer;						 //�����жϻ���
uint8_t Uart8_Rx_Cnt = 0;			 //���ջ������


extern	uint16_t test;
extern char RxBuffer1[];   //��������
extern uint8_t aRxBuffer1;						 //�����жϻ���
extern uint8_t Uart8_Rx_Cnt1 ;			 //���ջ������


/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
static void PUMP();
static void pest();
/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */
//    if (HAL_UART_Receive_IT(&huart2, (uint8_t *)USART_RX_BUF1, 1) != HAL_OK)
//    {
//        Error_Handler();
//    }
				//��whileѭ��ǰ���������ж�
				HAL_UART_Receive_IT(&huart2, (uint8_t *)&aRxBuffer, 1);	

	
  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
	xTaskCreate((void *)DHT11, "DHT11", 128,NULL, osPriorityNormal, NULL);
//	xTaskCreate(esp, "esp", 128,NULL, osPriorityNormal, NULL);
	 xTaskCreate((void *)PUMP, "PUMP", 128,  NULL, osPriorityNormal, NULL);
	 	xTaskCreate((void *)pest, "pest", 128,  NULL, osPriorityNormal, NULL);
		esp_Init();
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the defaultTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  /* Infinite loop */
  for(;;)
  {
		for(uint32_t i = 0;i<(sizeof(uhADCxConvertedValue)/sizeof(uint16_t));i++)
		{
			/*##-1- Start the conversion process #######################################*/
			if (HAL_ADC_Start(&hadc3) != HAL_OK)
			{
				/* Start Conversation Error */
				Error_Handler();
			}
			/*##-2- Wait for the end of conversion #####################################*/
			/*  For simplicity reasons, this example is just waiting till the end of the
					conversion, but application may perform other tasks while conversion
					operation is ongoing. */
			if (HAL_ADC_PollForConversion(&hadc3, 100) != HAL_OK)
			{
				/* End Of Conversion flag not set on time */
				Error_Handler();
			}
			else
			{
				/* ADC conversion completed */
				/*##-3- Get the converted value of regular channel  ########################*/
				uhADCxConvertedValue[i] = HAL_ADC_GetValue(&hadc3);
				
				/* Convert the result from 16 bit value to the voltage dimension (mV unit) */
				/* Vref = 3.3 V */
				uhADCxInputVoltage[i] = ((uhADCxConvertedValue[i] * 100) / 0xFFFF);
			}
		}
		HAL_ADC_Stop(&hadc3);
		
		light_val   = uhADCxInputVoltage[0]; // 
		soil_val   = uhADCxInputVoltage[1]; // 
		adc3_inp10  = uhADCxInputVoltage[2]; // 
		adc3_inp11  = uhADCxInputVoltage[3]; 
		
		uint8_t text[20];

		sprintf((char *)&text, "light: %d   ", 100-light_val);
		LCD_ShowString(0, 0, ST7735Ctx.Width, 16, 16, text);
		sprintf((char *)&text, "soil: %d  ",  100-soil_val);
		LCD_ShowString(0, 16, ST7735Ctx.Width,16,16,text);
//		sprintf((char *)&text, "PC0: %d", adc3_inp10);
		LCD_ShowString(0, 32, ST7735Ctx.Width, 16, 16, pump_state);
//		sprintf((char *)&text, "PC1: %d",test);
		LCD_ShowString(0, 48, ST7735Ctx.Width,16,16,pest_state);

		vTaskDelay(500);
  }
  /* USER CODE END StartDefaultTask */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
static void PUMP()
{
	while(1)
	{
		if(soil_val>50)
		{
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_SET);
			sprintf((char *)&pump_state, "PUMP:ON ");
			pump_state1=1;
		}
		else
		{
			HAL_GPIO_WritePin(GPIOA,GPIO_PIN_0,GPIO_PIN_RESET);
			sprintf((char *)&pump_state, "PUMP:OFF");
			pump_state1=0;
		}
	}
	vTaskDelay(100);
}

static void pest()
{
	
	while(1)
	{
				if(Uart8_Rx_Cnt==55)   //k210
				{
					Uart8_Rx_Cnt=0;
					if(strncmp(RxBuffer,"butterfly",5)==0)
					{
						sprintf((char *)&pest_state, "butterfly");
						pest_state1=1;
					}
					else if(strncmp(RxBuffer,"maomao",6)==0)
					{
						sprintf((char *)&pest_state, "maomao");
						pest_state1=2;
					}
					else
					{
						sprintf((char *)&pest_state, "NORMAL    ");
						pest_state1=0;
					}
	
					memset(RxBuffer,0,strlen(RxBuffer));
					Uart8_Rx_Cnt=0;
				}	
				else
				{
					sprintf((char *)&pest_state, "NORMAL    ");
					pest_state1=0;
				}
				vTaskDelay(100);
	}

}



	
/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  /* ��ֹδʹ�õĲ������뾯�� */
  UNUSED(huart);
  /* ע�⣺ ��Ҫ�ص�ʱ����Ӧ�޸ĸú�����
           �����û��ļ���ʵ�� HAL_UART_TxCpltCallback */ 
	
 if(huart->Instance == USART1)
    {
        if(Uart8_Rx_Cnt1 >= 255)  //����ж�
        {
            Uart8_Rx_Cnt1 = 0;
            memset(RxBuffer1, 0x00, sizeof(RxBuffer));
            HAL_UART_Transmit(&huart1, (uint8_t *)"USART1 �������", 16, 0xFFFF);     
        }
        else
        {
            RxBuffer1[Uart8_Rx_Cnt1++] = aRxBuffer1;   //��������ת��
            if((RxBuffer1[Uart8_Rx_Cnt1-1] == 0x0A) && (RxBuffer1[Uart8_Rx_Cnt1-2] == 0x0D)) //�жϽ���λ
            {
                Uart8_Rx_Cnt1 = 0;
                // ����������������
            }
        }
        HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRxBuffer1, 1);   //�ٿ��������ж�
    }
	
 if(huart->Instance == USART2)
    {
				if(Uart8_Rx_Cnt >= 255)  //����ж�
				{
					Uart8_Rx_Cnt = 0;
					memset(RxBuffer,0x00,sizeof(RxBuffer));
					HAL_UART_Transmit(&huart2, (uint8_t *)"�������", 10,0xFFFF); 	       
				}
				else
				{
					RxBuffer[Uart8_Rx_Cnt++] = aRxBuffer;   //��������ת��
					if((RxBuffer[Uart8_Rx_Cnt-1] == 0x0A)&&(RxBuffer[Uart8_Rx_Cnt-2] == 0x0D)) //�жϽ���λ
					{
			//			printf("Uart8�յ������ݣ�\n\r");
			//			HAL_UART_Transmit(&huart8, (uint8_t *)&RxBuffer, Uart8_Rx_Cnt,0xFFFF); //���յ�����Ϣ���ͳ�ȥ
			//            while(HAL_UART_GetState(&huart8) == HAL_UART_STATE_BUSY_TX);//���UART���ͽ���
						

						
						Uart8_Rx_Cnt = 55;
			//			memset(RxBuffer,0x00,sizeof(RxBuffer)); //�������
					}
				}

				HAL_UART_Receive_IT(&huart2, (uint8_t *)&aRxBuffer, 1);   //�ٿ��������ж�
			}
		}


/* USER CODE END Application */

