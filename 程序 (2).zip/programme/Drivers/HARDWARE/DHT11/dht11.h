#ifndef __BSP_DHT11_H
#define __BSP_DHT11_H
 
#include "tim.h"
#include "stm32h7xx.h"
 
#define BSP_DHT11_PORT		GPIOA   
#define BSP_DHT11_PIN			GPIO_PIN_1       
 
#define DHT11_OUT_1				HAL_GPIO_WritePin(BSP_DHT11_PORT, BSP_DHT11_PIN, GPIO_PIN_SET)
#define DHT11_OUT_0				HAL_GPIO_WritePin(BSP_DHT11_PORT, BSP_DHT11_PIN, GPIO_PIN_RESET)
 
#define DHT11_IN					HAL_GPIO_ReadPin(BSP_DHT11_PORT, BSP_DHT11_PIN)
 
typedef struct
{
	uint8_t humi_int;				// ʪ�ȵ���������
	uint8_t humi_deci;	 		// ʪ�ȵ�С������
	uint8_t temp_int;	 			// �¶ȵ���������
	uint8_t temp_deci;	 		// �¶ȵ�С������
	uint8_t check_sum;	 		// У���
		                 
} DHT11_Data_TypeDef;
 
uint8_t DHT11_ReadData(DHT11_Data_TypeDef* DHT11_Data);
void DHT11(void);
 
#endif	/* __BSP_DHT11_H */
