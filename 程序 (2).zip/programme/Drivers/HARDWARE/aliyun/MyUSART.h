#ifndef __MyUSART_H
#define __MyUSART_H
void MyUSART_Init(void);
char* MyUSART_GetString(void);
void MyUSART_SendString(char* str);
void UsartPrintf(USART_TypeDef *USARTx, char *fmt,...);
#endif
