#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "cmsis_os.h"
#include "FreeRTOS.h"                   // ARM.FreeRTOS::RTOS:Core
#include "task.h"                       // ARM.FreeRTOS::RTOS:Core
#include "event_groups.h"               // ARM.FreeRTOS::RTOS:Event Groups
#include "semphr.h"                     // ARM.FreeRTOS::RTOS:Core

//#include "MyUSART.h"
#include "string.h"
#include "stdio.h"
#include "usart.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//extern int BodyTemp;

static void esp();

extern int t;//定时器变量 100ms会自加

extern uint16_t light_val;//
extern uint16_t soil_val;//
//extern uint16_t temp_val;//
 
extern uint8_t pump_state1;  //0 off 1on    
extern uint8_t pest_state1;     //0 normal  1butterfly 2maomao

const char* WIFI ="1";
const char* WIFIASSWORD="111111111";
const char* ClintID="iln6Mz2Kz6m.pest_device|securemode=2\\,signmethod=hmacsha256\\,timestamp=1720597102138|";
const char* username="pest_device&iln6Mz2Kz6m";
const char* passwd="2188001804b0e26dd76f7021fa3a092e56e78ad7c1bba45cefe1bca377a8b293";
const char* Url="iot-06z00j27i87k9ra.mqtt.iothub.aliyuncs.com";
const char* pubtopic="/sys/iln6Mz2Kz6m/LoRa_device/thing/event/property/post";
const char* subtopic1="/sys/idahGM6dwiL/LoRa_device/thing/event/property/post_reply";
//const char* pubtopic="/idahGM6dwiL/LoRa_device/user/8266";
const char* subtopic="/iln6Mz2Kz6m/pest_device/user/get";
const char* func1="light";
const char* func2="soil";
const char* func3="temperature";
const char* func4="pump_state";
const char* func5="pest_state";



#define RXBUFFERSIZE  256      //最大接收字节数
char RxBuffer1[RXBUFFERSIZE];   //接收数据
uint8_t aRxBuffer1;						 //接收中断缓冲
uint8_t Uart8_Rx_Cnt1 = 0;			 //接收缓冲计数

////在while循环前启动串口中断
//	HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRxBuffer1, 1);	
//	
/* USER CODE BEGIN 4 */
//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
//{
//  /* 防止未使用的参数编译警告 */
//  UNUSED(huart);
//  /* 注意： 需要回调时，不应修改该函数、
//           可在用户文件中实现 HAL_UART_TxCpltCallback */ 
//	if(Uart8_Rx_Cnt1 >= 255)  //溢出判断
//	{
//		Uart8_Rx_Cnt1 = 0;
//		memset(RxBuffer1,0x00,sizeof(RxBuffer1));
//		HAL_UART_Transmit(&huart1, (uint8_t *)"数据溢出", 10,0xFFFF); 	       
//	}
//	else
//	{
//		RxBuffer1[Uart8_Rx_Cnt1++] = aRxBuffer1;   //接收数据转存
//		if((RxBuffer1[Uart8_Rx_Cnt1-1] == 0x0A)&&(RxBuffer1[Uart8_Rx_Cnt1-2] == 0x0D)) //判断结束位
//		{
////			printf("Uart8收到的数据：\n\r");
////			HAL_UART_Transmit(&huart1, (uint8_t *)&RxBuffer1, Uart8_Rx_Cnt1,0xFFFF); //将收到的信息发送出去
////            while(HAL_UART_GetState(&huart1) == HAL_UART_STATE_BUSY_TX);//检测UART发送结束
//			Uart8_Rx_Cnt1 = 0;
////			memset(RxBuffer1,0x00,sizeof(RxBuffer1)); //清空数组
//		}
//	}

//	HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRxBuffer1, 1);   //再开启接收中断
//}


int fputc(int ch,FILE *f )   //printf重定向  
{
	 HAL_UART_Transmit(&huart1, (uint8_t *)&ch, 1, 0xffff);
  return ch;
}
char esp_Init(void)
{
	//在while循环前启动串口中断
	HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRxBuffer1, 1);	
	
	xTaskCreate(esp, "esp", 128,NULL, osPriorityNormal, NULL);
	
//	memset(RxBuffer1,0,sizeof(RxBuffer1));
//	printf("AT+RST\r\n");  //重启
//	vTaskDelay(800);
//	vTaskDelay(800);
//	vTaskDelay(800);
//	memset(RxBuffer1,0,sizeof(RxBuffer1));
//	printf("ATE0\r\n");    //关闭回显
//	vTaskDelay(100);
//	if(strcmp(RxBuffer1,"OK"))
//		return 1;
//	
//	printf("AT+CWMODE=1\r\n"); //Station模式
//	vTaskDelay(1000);
//	if(strcmp(RxBuffer1,"OK"))
//		return 2;
//	
//	memset(RxBuffer1,0,sizeof(RxBuffer1));
//	printf("AT+CWJAP=\"%s\",\"%s\"\r\n",WIFI,WIFIASSWORD); //连接热点
//	vTaskDelay(800);
//	vTaskDelay(800);
//	vTaskDelay(800);
//	vTaskDelay(800);
//	if(strcmp(RxBuffer1,"OK"))
//		return 3;
//	
//	memset(RxBuffer1,0,sizeof(RxBuffer1));
//	printf("AT+MQTTUSERCFG=0,1,\"%s\",\"%s\",\"%s\",0,0,\"\"\r\n",ClintID,username,passwd);//用户信息配置
//	vTaskDelay(800);
//	if(strcmp(RxBuffer1,"OK"))
//		return 4;
//	
//	memset(RxBuffer1,0,sizeof(RxBuffer1));
//	printf("AT+MQTTCONN=0,\"%s\",1883,1\r\n",Url); //连接服务器
//	vTaskDelay(1000);
//	if(strcmp(RxBuffer1,"OK"))
//		return 5;
//	
//	printf("AT+MQTTSUB=0,\"%s\",1\r\n",subtopic); //订阅消息
//	vTaskDelay(800);
//	vTaskDelay(800);
//	printf("AT+MQTTSUB=0,\"%s\",1\r\n",subtopic1); //订阅消息
//	vTaskDelay(800);
//	if(strcmp(RxBuffer1,"OK"))
//		return 5;
//	memset(RxBuffer1,0,sizeof(RxBuffer1));
	return 0;
}
//功能：esp发送消息
//参数：无
//返回值：0：发送成功；1：发送失败
char Esp_PUB(void)
{
	memset(RxBuffer1,0,sizeof(RxBuffer1));
//	printf("AT+MQTTPUB=0,\"%s\",\"{\\\"method\\\":\\\"thing.event.property.post\\\"\\,\\\"params\\\":{\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d}}\",0,0\r\n",pubtopic,func1,CO_val,func2,CH4_val,func3,temperature,func4,humidity);
//	vTaskDelay(100);
//	printf("AT+MQTTPUB=0,\"%s\",\"{\\\"method\\\":\\\"thing.event.property.post\\\"\\,\\\"params\\\":{\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d\\,\\\"%s\\\":%d}}\",0,0\r\n",pubtopic,func5,temp_threshold,func6,humi_threshold,func7,CO_threshold,func8,CH4_threshold);
//	vTaskDelay(100);
//	printf("AT+MQTTPUB=0,\"%s\",\"{\\\"method\\\":\\\"thing.event.property.post\\\"\\,\\\"params\\\":{\\\"%s\\\":%d\\,\\\"%s\\\":%d}}\",0,0\r\n",pubtopic,func9,pm25_threshold,func10,warn_flag);
	
		printf("AT+MQTTPUB=0,\"/iln6Mz2Kz6m/pest_device/user/pest_device\",\"{\\\"light\\\":%d\\,\\\"soil\\\":%d\\,\\\"pump_state\\\":%d\\,\\\"pest_state\\\":%d}\",1,0\r\n",light_val,soil_val,pump_state1,pest_state1);
//  	vTaskDelay(260);
//		printf("AT+MQTTPUB=0,\"/idahGM6dwiL/LoRa_device/user/8266\",\"{\\\"temp_t\\\":%d\\,\\\"humi_t\\\":%d\\,\\\"CO_t\\\":%d\\,\\\"CH4_t\\\":%d\\,\\\"pm25_t\\\":%d\\,\\\"warn\\\":%d}\",1,0\r\n",temp_threshold,humi_threshold,CO_threshold,CH4_threshold,pm25_threshold,warn_flag);

//	

	
	//while(RxBuffer1[0]);//等待ESP返回数据
	vTaskDelay(200);//延时等待数据接收完成
	if(strcmp(RxBuffer1,"ERROR")==0)
		return 1;
	return 0;
}


static void esp()
{
	memset(RxBuffer1,0,sizeof(RxBuffer1));
		printf("AT+RST\r\n");  //重启
		vTaskDelay(800);
		vTaskDelay(800);
		vTaskDelay(800);
		memset(RxBuffer1,0,sizeof(RxBuffer1));
		printf("ATE0\r\n");    //关闭回显
		vTaskDelay(100);
		while(strcmp(RxBuffer1,"OK")==1)
		
		printf("AT+CWMODE=1\r\n"); //Station模式
		vTaskDelay(1000);
		while(strcmp(RxBuffer1,"OK")==1)
		
		memset(RxBuffer1,0,sizeof(RxBuffer1));
		printf("AT+CWJAP=\"%s\",\"%s\"\r\n",WIFI,WIFIASSWORD); //连接热点
		vTaskDelay(800);
		vTaskDelay(800);
		vTaskDelay(800);
		vTaskDelay(800);
		while(strcmp(RxBuffer1,"OK")==1)
		
		memset(RxBuffer1,0,sizeof(RxBuffer1));
		printf("AT+MQTTUSERCFG=0,1,\"%s\",\"%s\",\"%s\",0,0,\"\"\r\n",ClintID,username,passwd);//用户信息配置
		vTaskDelay(800);
		while(strcmp(RxBuffer1,"OK")==1)
		
		memset(RxBuffer1,0,sizeof(RxBuffer1));
		printf("AT+MQTTCONN=0,\"%s\",1883,1\r\n",Url); //连接服务器
		vTaskDelay(1000);
		while(strcmp(RxBuffer1,"OK")==1)
		
		printf("AT+MQTTSUB=0,\"%s\",1\r\n",subtopic); //订阅消息
		vTaskDelay(800);
		vTaskDelay(800);
//		printf("AT+MQTTSUB=0,\"%s\",1\r\n",subtopic1); //订阅消息
//		vTaskDelay(800);
		while(strcmp(RxBuffer1,"OK")==1)
		memset(RxBuffer1,0,sizeof(RxBuffer1));
		
		
	while(1)
	{
			Esp_PUB();
			vTaskDelay(300);
	}

}






//void CommandAnalyse(void)   //esp8266接收阿里云转发过来的数据
//{
//	if(strncmp(RxBuffer1,"+MQTTSUBRECV:",13)==0)
//	{
//		uint8_t iw=0,num=0;
//		while(RxBuffer1[iw++] != '\0')             
//		{
//			if(strncmp((RxBuffer1+iw),"temp_t",6)==0)
//			{
//				while(RxBuffer1[iw++] != ':');   
//				num = atoi(RxBuffer1+iw);
//				temp_threshold=num;
//			}
//			if(strncmp((RxBuffer1+iw),"humi_t",6)==0)
//			{
//				while(RxBuffer1[iw++] != ':');
//			num = atoi(RxBuffer1+iw);
//				humi_threshold=num; 
//			}
//			if(strncmp((RxBuffer1+iw),"CO_t",4)==0)
//			{
//				while(RxBuffer1[iw++] != ':');
//			num = atoi(RxBuffer1+iw);
//				CO_threshold=num;
//			}
//			if(strncmp((RxBuffer1+iw),"CH4_t",5)==0)
//			{
//				while(RxBuffer1[iw++] != ':');
//			num = atoi(RxBuffer1+iw);
//				CH4_threshold=num;
//			}
//			if(strncmp((RxBuffer1+iw),"pm25_t",6)==0)
//			{
//				while(RxBuffer1[iw++] != ':');
//			num = atoi(RxBuffer1+iw);
//				pm25_threshold=num;
//			}
//			if(strncmp((RxBuffer1+iw),"warn_h",6)==0)
//			{
//				while(RxBuffer1[iw++] != ':');
//			num = atoi(RxBuffer1+iw);
//				warn_hand=num;
//			}
//			if(strncmp((RxBuffer1+iw),"warn",4)==0)
//			{
//				while(RxBuffer1[iw++] != ':');
//			num = atoi(RxBuffer1+iw);
//				warn_flag=num;
//			}

		
		
//			if(strncmp((RxBuffer1+i),"warn",5)==0)
//			{
//				LED_State=1;
//				printf("AT+MQTTPUB=0,\"iln6FIgxs23/intelligence_bed/user/intelligence_bed\",\"{\\\"niaochuang\\\":%d\\,\\\"weight\\\":%d\\,\\\"LED_Switch\\\":%d}\",1,0\r\n",niaochuang,Weight_Shiwu,LED_State);
//			}
//			if(strncmp((RxBuffer1+i),"ledoff",6)==0)
//			{
//				LED_State=0;
//				printf("AT+MQTTPUB=0,\"iln6FIgxs23/intelligence_bed/user/intelligence_bed\",\"{\\\"niaochuang\\\":%d\\,\\\"weight\\\":%d\\,\\\"LED_Switch\\\":%d}\",1,0\r\n",niaochuang,Weight_Shiwu,LED_State);

			
//		}
//			memset(RxBuffer1,0,sizeof(RxBuffer1));
//	}
//}




