# WeAct Studio
## ADC Test

ADC 测试，通过ADC读取Vrefint,温度,vbat

ADC test, read Vrefint, temperature,vbat by ADC