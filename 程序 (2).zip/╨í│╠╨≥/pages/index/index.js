import mqtt from'../../utils/mqtt.js';
const aliyunOpt = require('../../utils/aliyun/aliyun_connect.js');

let that = null;
let lockSubTopic = false;
Page({
    data:{

      //设置温度值和湿度值 
      //temperature:"",
      //humidity:"",
      
      light:0,
      soil:0,
      pump_state:0,
      pest_state:0,

      client:null,//记录重连的次数
      reconnectCounts:0,//MQTT连接的配置
      options:{
        protocolVersion: 4, //MQTT连接协议版本
        clean: false,
        reconnectPeriod: 1000, //1000毫秒，两次重新连接之间的间隔
        connectTimeout: 30 * 1000, //1000毫秒，两次重新连接之间的间隔
        resubscribe: true, //如果连接断开并重新连接，则会再次自动订阅已订阅的主题（默认true）
        clientId: 'iln6Mz2Kz6m.wechat|securemode=2,signmethod=hmacsha256,timestamp=1720599802501|',
        password: '2524999f777fd05f4683b26a7ac2d8dffd097cbac5f382258f26efdd40318860',
        username: 'wechat&iln6Mz2Kz6m',
      },

      aliyunInfo: {
        productKey: 'iln6Mz2Kz6m', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        deviceName: 'wechat', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        deviceSecret: 'be4c107687b67ac4bc0719abc29f38f7', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        regionId: 'cn-shanghai', //阿里云连接的三元组 ，请自己替代为自己的产品信息!!
        pubTopic: '/iln6Mz2Kz6m/wechat/user/WeChat', //发布消息的主题
        subTopic: '/iln6Mz2Kz6m/wechat/user/get', //订阅消息的主题
      },
    },

  onLoad:function(){
    that = this;
    let clientOpt = aliyunOpt.getAliyunIotMqttClient({
      productKey: that.data.aliyunInfo.productKey,
      deviceName: that.data.aliyunInfo.deviceName,
      deviceSecret: that.data.aliyunInfo.deviceSecret,
      regionId: that.data.aliyunInfo.regionId,
      port: that.data.aliyunInfo.port,
    });

    console.log("get data:" + JSON.stringify(clientOpt));
    let host = 'wxs://k0n75sWZGM6.iot-as-mqtt.cn-shanghai.aliyuncs.com:443';
    
    this.setData({
      'options.clientId': clientOpt.clientId,
      'options.password': clientOpt.password,
      'options.username': clientOpt.username,
    })
    console.log("this.data.options host:" + host);
    console.log("this.data.options data:" + JSON.stringify(this.data.options));

    //访问服务器
    this.data.client = mqtt.connect(host, this.data.options);

    this.data.client.on('connect', function (connack) {
      wx.showToast({
        title: '连接成功'
      })
      console.log("连接成功");
    })

    //接收消息监听
    that.data.client.on("message", function (topic, payload) {
      //message是一个16进制的字节流
      let dataFromALY = {};
      try {
        dataFromALY = JSON.parse(payload);
        console.log(dataFromALY);
        if (dataFromALY.light!=null) {
          that.setData({
            light:dataFromALY.light||0,
            soil:dataFromALY.soil||0,
            pump_state:dataFromALY.pump_state||0,
            pest_state:dataFromALY.pest_state||0,
          })
        }
 
       

        // else if(dataFromALY.mp3_state!=null){
        //   that.setData({
        //     mp3_state:dataFromALY.mp3_state||0,
        //     tea5767_state:dataFromALY.tea5767_state||0,
        //   }) 
        // }
      } catch (error) {
        console.log(error);
      }
    })

    //服务器连接异常的回调
    that.data.client.on("error", function (error) {
      console.log(" 服务器 error 的回调" + error)

    })
    //服务器重连连接异常的回调
    that.data.client.on("reconnect", function () {
      console.log(" 服务器 reconnect的回调")

    })
    //服务器连接异常的回调
    that.data.client.on("offline", function (errr) {
      console.log(" 服务器offline的回调")
    })
  },
  

  
  
  onLedChange(event){

    const that = this
    const sw = event.detail.value
    if(sw==true){
      that.sendCommond(5);
    }
    else{
      that.sendCommond(6);
    }
  },
  onTogglePlay(event){

    const that = this
    if(!this.data.mp3_playingflag){
      that.sendCommond(8);
    }
    else{
      that.sendCommond(9);
    }
  },

  tea5767Play(event){
    const that = this
  if(!this.data.tea_playingflag){
    that.sendCommond(16);
  }
  else{
    that.sendCommond(15);
  }
},
  // onWaterPumpChange(event){

  //   const that = this
  //   const sw = event.detail.value
  //   if(sw==true){
  //     that.sendCommond(9);
  //   }
  //   else{
  //     that.sendCommond(10);
  //   }
  // },
  
  // onFlagChange(event){

  //   const that = this
  //   const sw = event.detail.value
  //   if(sw==true){
  //     that.sendCommond(11);
  //   }
  //   else{
  //     that.sendCommond(12);
  //   }
  // },

  singertemp() {
    that.sendCommond(0);
  },
  singerheart() {
    that.sendCommond(1);
  },
  singero2(){
    that.sendCommond(2);
  },
  singerniaochuang(){
    that.sendCommond(3);
  },
  singerweight(){
    that.sendCommond(4);
  },
  onPrevious(){
    that.sendCommond(7);
  },
  onUp(){
    that.sendCommond(10);
  },
  onDown(){
    that.sendCommond(11);
  },
  onNext(){
    that.sendCommond(12);
  },
  tea5767Previous(){
    that.sendCommond(13);
  },
  tea5767Next(){
    that.sendCommond(14);
  },


  sendCommond(data) {
    if (data==0) {
      data="singertemp"
    }else if(data==1)
    {
      data="singerheart"
    }
    else if(data==2)
    {
      data="singero2"
    }
    else if(data==3)
    {
      data="singerniaochuang"
    }
    else if(data==4)
    {
      data="singerweight"
    }
    else if(data==5)
    {
      data="ledon"
    }
    else if(data==6)
    {
      data="ledoff"
    }
    else if(data==7)
    {
      data="MP33"
    }
    else if(data==8)
    {
      data="MP31"
    }
    else if(data==9)
    {
      data="MP30"
    }
    else if(data==10)
    {
      data="MP34"
    }
    else if(data==11)
    {
      data="MP35"
    }
    else if(data==12)
    {
      data="MP32"
    }
    else if(data==13)
    {
      data="tea3"
    }
    else if(data==14)
    {
      data="tea2"
    }
    else if(data==15)
    {
      data="tea0"
    }
    else if(data==16)
    {
      data="tea1"
    }


    let sendData = {
       data,
    };


//此函数是订阅的函数，因为放在访问服务器的函数后面没法成功订阅topic，因此把他放在这个确保订阅topic的时候已成功连接服务器
//订阅消息函数，订阅一次即可 如果云端没有订阅的话，需要取消注释，等待成功连接服务器之后，在随便点击（开灯）或（关灯）就可以订阅函数
/*if(!lockSubTopic)
{
  this.data.client.subscribe(this.data.aliyunInfo.subTopic,function(err){
    if(!err){
      console.log("订阅成功");
      lockSubTopic = !lockSubTopic;
    };
    wx.showModal({
      content: "订阅成功",
      showCancel: false,
    })
  })   
}*/
    

    //发布消息
    if (this.data.client && this.data.client.connected) {
      this.data.client.publish(this.data.aliyunInfo.pubTopic, JSON.stringify(sendData));
      console.log(this.data.aliyunInfo.pubTopic)
      console.log(JSON.stringify(sendData))
    } else {
      wx.showToast({
        title: '请先连接服务器',
        icon: 'none',
        duration: 2000
      })
    }
  }
})